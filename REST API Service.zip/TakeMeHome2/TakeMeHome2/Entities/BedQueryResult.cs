﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TakeMeHome2.Entities {
    public class BedQueryResult {
        public string CenterId { get; set; }
        public string CenterName { get; set; }
        public string WebSite { get; set; }
        public int TotalBeds { get; set; }
        public int BedsAvailable { get; set; }
    }
}