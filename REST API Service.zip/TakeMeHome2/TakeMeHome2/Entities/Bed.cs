﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TakeMeHome2 {
    public class Bed {
        public string CenterId { get; set; }
        public int TotalBeds { get; set; }
        public int BedsAvailable { get; set; }
    }
}