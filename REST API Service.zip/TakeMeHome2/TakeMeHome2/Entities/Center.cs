﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TakeMeHome2.Entities {
    public class Center {
        public string CenterId { get; set; }
        public string CenterName { get; set; }
        public string WebSite { get; set; }
    }
}