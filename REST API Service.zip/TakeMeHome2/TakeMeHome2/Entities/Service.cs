﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TakeMeHome2.Entities {
    public class Service {
        public string ServiceId { get; set; }
        public string ServiceType { get; set; }
    }
}