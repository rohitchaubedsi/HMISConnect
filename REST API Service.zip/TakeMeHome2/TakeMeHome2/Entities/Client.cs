﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TakeMeHome2 {
    public class Client {

        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string SSN { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }
        public string WalkedIn { get; set; }
        public string CheckedIn { get; set; }
        public string IsNew { get; set; }
    }
}
