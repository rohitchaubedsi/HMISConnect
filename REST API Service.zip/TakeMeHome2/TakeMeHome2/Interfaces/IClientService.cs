﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Text;
using System.Web.Script.Services;

namespace TakeMeHome2 {
    [ServiceContract]
    public interface IClientService {
        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "/GetClientById/{Id}")]
        Message GetClientById(string Id);

        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "/CheckInClient?FirstName={firstName}&MiddleName={middleName}&LastName={lastName}&SSN={ssn}&DOB={dob}&Gender={gender}&WalkedIn={walkedIn}&CheckedIn={checkedIn}&IsNew={isNew}")]
        Message CheckInClient(string firstName, string middleName, string lastName, string ssn, string dob, string gender, string walkedIn, string checkedIn, string isNew);

    }
}
