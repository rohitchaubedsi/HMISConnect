﻿using System.Collections.Generic;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using TakeMeHome2.Entities;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Text;

namespace TakeMeHome2 {
    public class Beds : IBeds {
        public Message GetAvailableBedCount() {
            int result = 0;
            string output;
            System.Configuration.Configuration webConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/TakeMeHome2");
            using (MySqlConnection connection = new MySqlConnection(webConfig.ConnectionStrings.ConnectionStrings["TakeMeHome"].ConnectionString)) {
                connection.Open();
                string sql = "SELECT SUM(bedsavailable) from beds";
                using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                using (MySqlDataReader reader = cmd.ExecuteReader()) { 
                    while (reader.Read()) {
                        result = reader.GetInt32(0);
                    }
                }
                output = JsonConvert.SerializeObject(result);
            }
            return WebOperationContext.Current.CreateTextResponse(output, "application/json; charset=utf-8", Encoding.UTF8);
        }

        public Message GetAvailableBedsByAgeGender(string Gender, string Age) {
            List <BedQueryResult> beds = new List<BedQueryResult>();
            int result = 0;
            string output;
            string sql = string.Empty;
            System.Configuration.Configuration webConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/TakeMeHome2");
            using (MySqlConnection connection = new MySqlConnection(webConfig.ConnectionStrings.ConnectionStrings["TakeMeHome"].ConnectionString)) {
                connection.Open();
                //if (Gender == "F") {
                //    sql = "SELECT * FROM Beds Where bedsavailable > 1 LIMIT 3";
                //}
                //int intAge = 0;
                //int.TryParse(Age, out intAge);
                //if (Gender == "M" & intAge > 18) {
                //    sql = "SELECT * FROM Beds Where bedsavailable > 1 LIMIT 1";
                //}
                //if (Gender == "M" & intAge < 18) {
                //    sql = "SELECT * FROM Beds Where bedsavailable > 1 LIMIT 4";
                //}

                sql = @"SELECT centers.CenterID, CenterName, WebSite, bedsavailable, totalbeds FROM centers inner join centerservices on centers.CenterID = centerservices.CenterId inner join beds on centers.CenterID = beds.centerid where ServiceId = 7 and bedsavailable > 0";
                using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                using (MySqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        BedQueryResult bed = new BedQueryResult();
                        bed.CenterId = reader.GetString("CenterId");
                        bed.CenterName = reader.GetString("CenterName");
                        bed.WebSite = reader.GetString("WebSite");
                        bed.TotalBeds = reader.GetInt32("TotalBeds");
                        bed.BedsAvailable = reader.GetInt32("BedsAvailable");
                        beds.Add(bed);
                    }
                }
                output = JsonConvert.SerializeObject(beds);
            }
            return WebOperationContext.Current.CreateTextResponse(output, "application/json; charset=utf-8", Encoding.UTF8);
        }
    }
}
