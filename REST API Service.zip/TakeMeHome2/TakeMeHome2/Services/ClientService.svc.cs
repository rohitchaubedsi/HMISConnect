﻿
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Text;

namespace TakeMeHome2 {
    public class ClientService : IClientService {
        public Message GetClientById(string id) {

            Client client = new Client();
            string output = string.Empty; try {
                System.Configuration.Configuration webConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/TakeMeHome2");
                using (MySqlConnection connection = new MySqlConnection(webConfig.ConnectionStrings.ConnectionStrings["TakeMeHome"].ConnectionString)) {
                    connection.Open();
                    string sql = "SELECT First_Name, Middle_name, Last_Name, DOB, Gender, SSN, WalkedIn, CheckedIn from client where UUID = " + id;
                    using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                    using (MySqlDataReader reader = cmd.ExecuteReader()) {
                        int walkedInPos = reader.GetOrdinal("WalkedIn");
                        int checkedInPos = reader.GetOrdinal("CheckedIn");
                        while (reader.Read()) {
                            client.FirstName = reader.GetString("First_Name");
                            client.MiddleName = reader.GetString("Middle_Name");
                            client.LastName = reader.GetString("Last_Name");
                            client.DOB = reader.GetString("DOB");
                            client.Gender = reader.GetString("Gender");
                            client.SSN = reader.GetString("SSN");
                            client.WalkedIn = reader.IsDBNull(walkedInPos)
                                              ? string.Empty
                                              : reader.GetString("WalkedIn");
                            client.CheckedIn = reader.IsDBNull(checkedInPos)
                                              ? string.Empty
                                              : reader.GetString("CheckedIn");
                        }
                    }
                    output = JsonConvert.SerializeObject(client);
                }
            }
            catch (System.Exception e) {
                string t = "";
            }
            return WebOperationContext.Current.CreateTextResponse(output, "application/json; charset=utf-8", Encoding.UTF8);
        }

        public Message CheckInClient(string firstName, string middleName, string lastName, string ssn, string dob, string gender, string walkedIn, string checkedIn, string isNew) {
            int rows = 0;
            string output = string.Empty;
            dob = dob.Replace('-', '/');
            walkedIn = walkedIn.Replace('-', '/');
            checkedIn = checkedIn.Replace('-', '/');
            System.Configuration.Configuration webConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/TakeMeHome2");
            using (MySqlConnection connection = new MySqlConnection(webConfig.ConnectionStrings.ConnectionStrings["TakeMeHome"].ConnectionString)) {
                connection.Open();
                string sql = string.Format("INSERT INTO `takemehome`.`client` (`First_Name`, `Middle_Name`, `Last_Name`, `SSN`, `DOB`, `Gender`, `WalkedIn`, `CheckedIn`, `IsNew`) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', STR_TO_DATE('{6}', '%c/%e/%Y'), STR_TO_DATE('{7}', '%c/%e/%Y'), '{8}')", firstName, middleName, lastName, ssn, dob, gender, walkedIn, checkedIn, isNew);
                using (MySqlCommand cmd = new MySqlCommand(sql, connection)) {
                    rows = cmd.ExecuteNonQuery();
                }
                output = JsonConvert.SerializeObject(rows > 0);
            }
            return WebOperationContext.Current.CreateTextResponse(output, "application/json; charset=utf-8", Encoding.UTF8);
        }
    }
}
