﻿using System.Collections.Generic;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using TakeMeHome2.Entities;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;

namespace TakeMeHome2 {
    public class ServiceCenter : IServiceCenter {
        public Message GetServiceCenterInfo() {
            Dictionary<string, List<Service>> centerServices = new Dictionary<string, List<Service>>();
            Dictionary<string, Center> centers = new Dictionary<string, Center>();
            string output;
            System.Configuration.Configuration webConfig = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/TakeMeHome2");
            using (MySqlConnection connection = new MySqlConnection(webConfig.ConnectionStrings.ConnectionStrings["TakeMeHome"].ConnectionString)) {
                connection.Open();
                string sql = "SELECT * from centers";
                using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                using (MySqlDataReader reader = cmd.ExecuteReader()) {
                    while (reader.Read()) {
                        Center center = new Center();
                        center.CenterId = reader.GetString("CenterID");
                        center.CenterName = reader.GetString("CenterName");
                        center.WebSite = reader.GetString("WebSite");
                        centers.Add(center.CenterId, center);
                    }
                }

                foreach (var center in centers) {
                    sql = "SELECT * FROM takemehome.centerservices inner join takemehome.services on  centerservices.ServiceId = services.ServiceID where centerId = " + center.Key;
                    List<Service> services = new List<Service>();
                    using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                    using (MySqlDataReader reader = cmd.ExecuteReader()) {

                        while (reader.Read()) {
                            Service service = new Service();
                            service.ServiceId = reader.GetString("ServiceId");
                            service.ServiceType = reader.GetString("ServiceType");
                            services.Add(service);
                        }
                    }
                    centerServices.Add(center.Key, services);
                }

                output = JsonConvert.SerializeObject(centerServices);
            }
            return WebOperationContext.Current.CreateTextResponse(output, "application/json; charset=utf-8", Encoding.UTF8);
        }
    }
}
