package app.aydra.menumbo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class mainMenu extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }

    protected void getDemography(View view){
        Intent myintent = new Intent(this, Demography.class);
        startActivity(myintent);
    }

    protected void coc(View view){
        Intent myintent = new Intent(this, MainActivity.class);
        startActivity(myintent);
    }
}
