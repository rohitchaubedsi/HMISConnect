package app.aydra.menumbo;

import android.content.Context;
import android.support.v4.view.MotionEventCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import android.util.Log;

/**
 * Created by davvit on 9/22/2016.
 */

public class DataAdapter  extends RecyclerView.Adapter<DataAdapter.ViewHolder>{

    private static final String DEBUG_TAG = "DEBUG";
    private List<DataModel> mdata;
    private Context mContext;
    View previousView;

    public DataAdapter(Context context,List<DataModel> model){
        mdata = model;
        mContext = context;
    }



    private Context getmContext(){
        return mContext;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.row_layout, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(context,contactView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int position) {
// Get the data model based on position
        DataModel data = mdata.get(position);

        // Set item views based on your views and data model
        TextView textView = viewHolder.nameTextView;
        textView.setText(data.getName());
        TextView textView2 = viewHolder.emailTextView;
        textView2.setText(data.getEmail());
        TextView textView3 = viewHolder.addressTextView;
        textView3.setText(data.getAddress());
        TextView textView4 = viewHolder.numberTextView;
        textView4.setText(data.getNumber());
    }

    @Override
    public int getItemCount() {
        return mdata.size();
    }


    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView nameTextView;
        public TextView numberTextView;
        public TextView emailTextView;
        public TextView addressTextView;
        private Context context;

        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(Context context, View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);

            nameTextView = (TextView) itemView.findViewById(R.id.contact_name);
            numberTextView = (TextView) itemView.findViewById(R.id.contact_number);
            emailTextView = (TextView)itemView.findViewById(R.id.contact_email);
            addressTextView =(TextView)itemView.findViewById(R.id.contact_address);

            this.context = context;
            // Attach a click listener to the entire row view
            itemView.setOnClickListener(this);
        }



        @Override
        public void onClick(View v) {
            if (previousView != null) {
                previousView.findViewById(R.id.options).setVisibility(View.GONE);
            }

            int position = getAdapterPosition();

            DataModel selectedModel = mdata.get(position);
            Toast.makeText(context, "Calling... " + selectedModel.getName(), Toast.LENGTH_SHORT).show();
        }
    }
}
