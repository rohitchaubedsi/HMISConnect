package app.aydra.menumbo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Demography extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demography);

    }

    protected void Search(View view){
        Intent myintent = new Intent(this, result.class);
        startActivity(myintent);
    }

}
