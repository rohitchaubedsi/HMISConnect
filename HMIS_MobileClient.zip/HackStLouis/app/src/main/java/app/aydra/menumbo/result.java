package app.aydra.menumbo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import static app.aydra.menumbo.R.id.activity_result2;

public class result extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result2);
    }

    protected void call(View view){
        Toast.makeText(getApplicationContext(), "Calling... ", Toast.LENGTH_SHORT).show();
    }

}
