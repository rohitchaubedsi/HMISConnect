package app.aydra.menumbo;

import java.util.ArrayList;

public class DataModel {
    private String name;
    private String number;
    private String email;
    private  String address;

    public DataModel(String name, String email, String address, String number) {
        this.name = name;
        this.email = email;
        this.address = address;
        this.number = number;
    }

    public static ArrayList<DataModel> createListOfItems(int amount) {
        ArrayList<DataModel> contacts = new ArrayList<DataModel>();

        for (int i = 0; i <= amount; i++) {
            contacts.add(new DataModel("", "", "User " + Integer.toString(i), "000-000-0000"));
        }

        return contacts;
    }

    public static ArrayList<DataModel> loadData(){
        ArrayList<DataModel> contacts = new ArrayList<DataModel>();

        String Name[] = {"Almost Home", "BJC Behavioral Health", "Bridgeway Behavioral Health","Catholic Charities Housing Resource Center","Catholic Family Services","Center for Women in Transition","Covenant House of Missouri","Doorways","Employment Connection","Equal Housing Opportunity Council","Family Care Health Center","Gateway 180","Grace Hill","Grace& Peace","Haven of Grace","Humanitri","International Institute","Legal Services of Eastern Missouri","Lydia's House","Missouri Department of Mental Health","Missouri Housing Development Commission (MHDC)","Missouri Probation & Parole","Municipal Information Systems, Inc.              ","Neighborhood Stabilization","Our Lady's Inn","Paraquad","Peter & Paul Community Services, Inc.            ","Places for People (formerly Community Alternative","Preferred Family Healthcare, Inc.                ","Queen of Peace","Redevelopment Opportunities for Women","Shalom House","Social Security Administration","Society of St. Vincent de Paul","St. Francis Xavier","St. John's Mercy Neighborhood Ministry","St. Louis Agency on Training & Education (SLATE)","St. Louis City Health Department","St. Louis Housing Authority","St. Louis Empowerment Center","St. Louis Office of DD Resources","St. Louis Transitional Hope House","St. Martha's Hall","St. Patrick Center","Stepping Into the Light","The Bridge","The Salvation Army","The Women's Safe House","United Way","Urban League of Metropolitan St. Louis","Urban Strategies","Veteran's Administration Medical Center","YWCA"};
        String email[] = {"www.almosthomestl.org","www.bjc.org","www.bridgewaybh.com","www.ccstl.org","www.cfsstl.org","www.cwitstl.org","www.covenanthousemo.org","www.doorwayshousing.org","www.employmentstl.org","www.ehocstl.org","www.familycarehealthcenter.org","www.gateway180.org","www.gracehill.org","www.graceandpeacefellowship.org","www.havenofgracestl.org","www.humanitri.org","www.iistl.org","www.lsem.org","www.lydiashouse.org","www.dmh.missouri.org","www.mhdc.com","www.doc.mo.gov","www.misi.org","","www.ourladysinn.org","www.paraquad.org","www.ppcsinc.org","www.community-alternatives.org","www.pfh.org","www.qopcstl.org","www.row-stl.org","www.shalomhousestl.org","www.socialsecurity.gov","www.svdpstlouis.org","www.collegechurch.slu.edu","www.stjohnsmercy.org","","","www.slha.org","www.stlempowerment.org","www.stldd.org","www.hopehousestl.org","www.saintmarthas.org","www.stpatrickcenter.org","www.netministries.org","www.bridgestl.org","www.stl-salvationarmy.org","www.twsh.org","www.stl.unitedway.org","www.ulstl.org","www.urbanstrategiesinc.org","www.stlouis.va.gov","www.ywcastlouis.org"};
        String address[]={"3200 St Vincent Ave, St. Louis, MO 63104","4901 Forest Park Avenue St. Louis, Missouri 63108","2510 S. Brentwood, Suite 315, St. Louis, MO 63144","3201 St Vincent Ave, St. Louis, MO 63104","4902 Forest Park Avenue St. Louis, Missouri 63108","2511 S. Brentwood, Suite 315, St. Louis, MO 63144","3202 St Vincent Ave, St. Louis, MO 63104","4903 Forest Park Avenue St. Louis, Missouri 63108","2512 S. Brentwood, Suite 315, St. Louis, MO 63144","3203 St Vincent Ave, St. Louis, MO 63104","4904 Forest Park Avenue St. Louis, Missouri 63108","2513 S. Brentwood, Suite 315, St. Louis, MO 63144","3204 St Vincent Ave, St. Louis, MO 63104","4905 Forest Park Avenue St. Louis, Missouri 63108","2514 S. Brentwood, Suite 315, St. Louis, MO 63144","3205 St Vincent Ave, St. Louis, MO 63104","4906 Forest Park Avenue St. Louis, Missouri 63108","3201 St Vincent Ave, St. Louis, MO 63104","4902 Forest Park Avenue St. Louis, Missouri 63108","2511 S. Brentwood, Suite 315, St. Louis, MO 63144","3202 St Vincent Ave, St. Louis, MO 63104","4903 Forest Park Avenue St. Louis, Missouri 63108","2512 S. Brentwood, Suite 315, St. Louis, MO 63144","3203 St Vincent Ave, St. Louis, MO 63104","4904 Forest Park Avenue St. Louis, Missouri 63108","2513 S. Brentwood, Suite 315, St. Louis, MO 63144","3204 St Vincent Ave, St. Louis, MO 63104","4905 Forest Park Avenue St. Louis, Missouri 63108","2514 S. Brentwood, Suite 315, St. Louis, MO 63144","3205 St Vincent Ave, St. Louis, MO 63104","4906 Forest Park Avenue St. Louis, Missouri 63108","2515 S. Brentwood, Suite 315, St. Louis, MO 63144","3206 St Vincent Ave, St. Louis, MO 63104","4907 Forest Park Avenue St. Louis, Missouri 63108","3202 St Vincent Ave, St. Louis, MO 63104","4903 Forest Park Avenue St. Louis, Missouri 63108","2512 S. Brentwood, Suite 315, St. Louis, MO 63144","3203 St Vincent Ave, St. Louis, MO 63104","4904 Forest Park Avenue St. Louis, Missouri 63108","2513 S. Brentwood, Suite 315, St. Louis, MO 63144","3204 St Vincent Ave, St. Louis, MO 63104","4905 Forest Park Avenue St. Louis, Missouri 63108","2514 S. Brentwood, Suite 315, St. Louis, MO 63144","3205 St Vincent Ave, St. Louis, MO 63104","4906 Forest Park Avenue St. Louis, Missouri 63108","2515 S. Brentwood, Suite 315, St. Louis, MO 63144","3206 St Vincent Ave, St. Louis, MO 63104","4907 Forest Park Avenue St. Louis, Missouri 63108","2516 S. Brentwood, Suite 315, St. Louis, MO 63144","3207 St Vincent Ave, St. Louis, MO 63104","4908 Forest Park Avenue St. Louis, Missouri 63108","3203 St Vincent Ave, St. Louis, MO 63104","4904 Forest Park Avenue St. Louis, Missouri 63108"};
        String Phone[]={"(314) 771-4663", "(314) 286-2000","(636) 224-1600","(314) 771-4664","(314) 286-2001","(636) 224-1601","(314) 771-4665","(314) 286-2002","(636) 224-1602","(314) 771-4666","(314) 286-2003","(636) 224-1603","(314) 771-4667","(314) 286-2004","(636) 224-1604","(314) 771-4668","(314) 286-2005","(314) 771-4664","(314) 286-2001","(636) 224-1601","(314) 771-4665","(314) 286-2002","(636) 224-1602","(314) 771-4666","(314) 286-2003","(636) 224-1603","(314) 771-4667","(314) 286-2004","(636) 224-1604","(314) 771-4668","(314) 286-2005","(636) 224-1605","(314) 771-4669","(314) 286-2006","(314) 771-4665","(314) 286-2002","(636) 224-1602","(314) 771-4666","(314) 286-2003","(636) 224-1603","(314) 771-4667","(314) 286-2004","(636) 224-1604","(314) 771-4668","(314) 286-2005","(636) 224-1605","(314) 771-4669","(314) 286-2006","(636) 224-1606","(314) 771-4670","(314) 286-2007","(314) 771-4666","(314) 286-2003"};

        for (int i = 0; i <= 52; i++) {
            contacts.add(new DataModel(Name[i],email[i],address[i],Phone[i]));
        }

        return contacts;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getEmail(){return email;}
    public String getAddress(){return address;}


    @Override
    public boolean equals(Object obj) {
        if(obj ==null || ! (obj instanceof DataModel)){
            return false;
        }

        DataModel model2 = (DataModel)obj;
        if(model2.getName().equals(this.getName())){
            return true;
        }

        return false;
    }
}
