﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace WebApplication3 {
    public class HttpWebRequest {
        internal string baseUrl = string.Empty;
        internal static HttpClient httpClient;
        public HttpWebRequest(string serviceUrl) {
            baseUrl = string.Format("http://localhost:30009/Services/{0}", serviceUrl);
        }

        #region -- Helper Execute Methods --

        /// <summary>Create HTTP Client</summary>
        /// <param name="authId">Optional AuthId</param>
        /// <returns></returns>
        private HttpClient GetHttpClient() {
            if (httpClient == null) {
                httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(baseUrl);
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("accept", "application/json");
            }
            return httpClient;
        }

        /// <summary>Create HTTPResponse Message for POST with authorization ID</summary>
        /// <param name="content">StringContent to send</param>
        /// <param name="url">Http Url</param>
        /// <returns></returns>
        public HttpResponseMessage ExecutePost(StringContent content) {
            HttpClient client = GetHttpClient();
            HttpResponseMessage response = client.PostAsync(baseUrl, content).Result;

            if (response.StatusCode == HttpStatusCode.Unauthorized) {
                client.Dispose();
                client = GetHttpClient();
                response = client.PostAsync(baseUrl, content).Result;
            }
            return response;
        }

        /// <summary>Create HTTPResponse Message for PUT with authorization ID</summary>
        /// <param name="content"></param>
        /// <param name="url">Http Url</param>
        /// <returns></returns>
        public HttpResponseMessage ExecutePut(StringContent content) {
            HttpClient client = GetHttpClient();
            HttpResponseMessage response = client.PutAsync(baseUrl, content).Result;

            if (response.StatusCode == HttpStatusCode.Unauthorized) {
                client.Dispose();
                client = GetHttpClient();
                response = client.PutAsync(baseUrl, content).Result;
            }

            return response;
        }

        /// <summary>Create HTTPResponse Message for GET</summary>
        /// <param name="url">Http Url</param>
        /// <returns></returns>
        public HttpResponseMessage ExecuteGet() {
            HttpClient client = GetHttpClient();
            HttpResponseMessage response = client.GetAsync(baseUrl).Result;

            if (response.StatusCode == HttpStatusCode.Unauthorized) {
                client.Dispose();
                client = GetHttpClient();
                response = client.GetAsync(baseUrl).Result;
            }

            return response;
        }

        #endregion        
    }
}