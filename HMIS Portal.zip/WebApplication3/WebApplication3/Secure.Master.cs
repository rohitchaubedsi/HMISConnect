﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3 {
    public partial class Secure : System.Web.UI.MasterPage {
        protected void Page_Load(object sender, EventArgs e) {
            if (Session["FromCheckIn"] != null) {
                FromCheckIn.Text = Session["FromCheckIn"].ToString();
            }
            else {
                FromCheckIn.Text = "false";
            }
        }
    }
}