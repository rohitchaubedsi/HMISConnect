﻿using System;
using System.Net.Http;
using Newtonsoft.Json;

namespace WebApplication3 {
    public partial class Dashboard : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            if (Session["FromCheckIn"] == null) {
                Session["FromCheckIn"] = "false";
            }
            if (Request.QueryString["CheckIn"] != null) {
                Session["FromCheckIn"] = "true";
            }

            //HttpWebRequest httpWebRequest = new HttpWebRequest("ClientService.svc/GetClientById/90077");
            //HttpResponseMessage response = httpWebRequest.ExecuteGet();
            //string t = response.Content.ReadAsStringAsync().Result;
            //Client test = JsonConvert.DeserializeObject<Client>(t);
        }
    }
}